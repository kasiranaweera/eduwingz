import React from 'react'

const DashboardProfilePage = () => {
  return (
    <div>
      DashboardProfilePage
    </div>
  )
}

export default DashboardProfilePage
