import React from 'react'

const PrivacyPage = () => {
  return (
    <div>
      PrivacyPage
    </div>
  )
}

export default PrivacyPage
