import React from 'react'

const DownloadPage = () => {
  return (
    <div>
      DownloadPage
    </div>
  )
}

export default DownloadPage
