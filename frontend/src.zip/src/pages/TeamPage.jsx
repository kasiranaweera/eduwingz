import React from 'react'

const TeamPage = () => {
  return (
    <div>
      TeamPage
    </div>
  )
}

export default TeamPage
