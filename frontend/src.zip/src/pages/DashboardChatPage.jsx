import React from "react";
import { Box } from "@mui/material";

const DashboardChatPage = () => {
  return <Box>DashboardChatPage</Box>;
};

export default DashboardChatPage;
