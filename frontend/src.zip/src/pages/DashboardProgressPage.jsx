import React from 'react'

const DashboardProgressPage = () => {
  return (
    <div>
      DashboardProgressPage
    </div>
  )
}

export default DashboardProgressPage
