import { Box, Typography } from "@mui/material";
import img from '../assets/img/asdasdadadada.jpg'
import GlowCursor from "../components/common/GlowCursor";
import GoogleLoginButton from "../components/common/GoogleLoginButton";
import { GoogleOAuthProvider } from '@react-oauth/google';

const HomePage = () => {  
  return (
    <Box>
      {/* <GoogleOAuthProvider clientId="499873335308-30ummun4ga29qitl3kmvecv8ifgtue76.apps.googleusercontent.com">
      {/* Your app components */}
      {/* <GoogleLoginButton />
    </GoogleOAuthProvider> */} 
    </Box>
  );
};

export default HomePage;
