import React from 'react'

const ResearchPage = () => {
  return (
    <div>
      ResearchPage
    </div>
  )
}

export default ResearchPage
