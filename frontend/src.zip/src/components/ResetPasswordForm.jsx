import React from 'react'

const ResetPasswordForm = () => {
  return (
    <div>
      ResetPasswordForm
    </div>
  )
}

export default ResetPasswordForm
