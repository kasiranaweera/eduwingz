import React from 'react'

const ChatBookmarkPage = () => {
  return (
    <div>
      ChatBookmarkPage
    </div>
  )
}

export default ChatBookmarkPage
