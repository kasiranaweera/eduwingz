import React from 'react'

const ResourcesPage = () => {
  return (
    <div>
      ResourcesPage
    </div>
  )
}

export default ResourcesPage
