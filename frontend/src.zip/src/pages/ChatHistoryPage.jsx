import React from 'react'

const ChatHistoryPage = () => {
  return (
    <div>
      ChatHistoryPage
    </div>
  )
}

export default ChatHistoryPage
