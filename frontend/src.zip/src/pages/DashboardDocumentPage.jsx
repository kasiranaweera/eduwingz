import React from 'react'

const DashboardDocumentPage = () => {
  return (
    <div>
      DashboardDocumentPage
    </div>
  )
}

export default DashboardDocumentPage
