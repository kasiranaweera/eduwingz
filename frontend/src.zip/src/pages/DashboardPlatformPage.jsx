import React from 'react'

const DashboardPlatformPage = () => {
  return (
    <div>
      DashboardPlatformPage
    </div>
  )
}

export default DashboardPlatformPage
