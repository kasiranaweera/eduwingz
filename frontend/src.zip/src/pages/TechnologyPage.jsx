import React from 'react'

const TechnologyPage = () => {
  return (
    <div>
      TechnologyPage
    </div>
  )
}

export default TechnologyPage
