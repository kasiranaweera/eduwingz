import React from 'react'

const FeaturesPage = () => {
  return (
    <div>
      FeaturesPage
    </div>
  )
}

export default FeaturesPage
